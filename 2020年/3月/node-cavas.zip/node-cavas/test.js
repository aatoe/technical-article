// 引用index.js 模块
const {drawImage} = require("./index.js")

// 传参数到index.js 
exports.params = {
    clientName:"Atoe",
    identifynNum:"4418940298784734567",
    frameNum:"LSVG026R9F2086645",
    GPScost:"1000",
    financialfee:"1000",
    summary:"2000",
}

drawImage()

