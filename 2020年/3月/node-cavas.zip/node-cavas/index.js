const fs = require('fs')
const {
    createCanvas
} = require('canvas')
const bufferFrom = require('buffer-from')
const Canvas = require('canvas')

// 接受参数
const params = require("./test.js")

function drawImage() {
    let arg = params
    const canvas = createCanvas(610, 550)
    const ctx = canvas.getContext('2d')
    var rectH = 60;
    ctx.lineWidth = .3;
    // 设置字体
    ctx.font = "25px 黑体";
    // 设置颜色
    ctx.fillStyle = "#000";
    // 设置水平对齐方式
    ctx.textAlign = "center";
    // 设置垂直对齐方式
    ctx.textBaseline = "middle";

    //绘制表格
    //第yi步：绘制竖线：如果绘制的格子的宽高相等，可以将for循环放到一个里面；
    for (var i = 0; i < canvas.height; i++) {
        ctx.strokeStyle = '#000';
        // ctx.style.border='1px solid gren';
        ctx.moveTo(5, rectH * i);
        ctx.lineTo(600, rectH * i);

    }

    // 绘制文字（参数：要写的字，x坐标，y坐标）
    canvas_text(ctx, "超融明细", "25px", '#000', 600, 55)
    ctx.font = "20px 黑体";
    canvas_text(ctx, "客户名称", "20px", '#000', 120, 180)
    canvas_text(ctx, arg.clientName, "20px", '#000', 320, 180)
    canvas_text(ctx, "身份证号码", "20px", '#000', 620, 180)
    canvas_text(ctx, arg.identifynNum, "20px", '#000', 980, 180)
    canvas_text(ctx, "车架号", "20px", '#000', 120, 300)
    canvas_text(ctx, arg.frameNum, "20px", '#000', 600, 300)

    canvas_text(ctx, "GPS费用", "20px", '#000', 180, 420)
    canvas_text(ctx, arg.GPScost, "20px", '#000', 780, 420)
    canvas_text(ctx, "金融服务费", "20px", '#000', 180, 540)
    canvas_text(ctx, arg.financialfee, "20px", '#000', 780, 540)
    canvas_text(ctx, "汇总", "20px", '#000', 180, 1020)
    canvas_text(ctx, arg.summary, "20px", '#000', 780, 1020)
    // 清除顶部多余的线条
    // ctx.clearRect(0,540,1,1);
    // 左边框
    ctx.moveTo(5, 5);
    ctx.lineTo(5, 540);
    // 右边框
    ctx.moveTo(600, 5);
    ctx.lineTo(600, 540);
    // 顶部边框
    ctx.moveTo(5, 5);
    ctx.lineTo(600, 5)
    // 底边框
    ctx.moveTo(5, 540);
    ctx.lineTo(600, 540);
    // 左上
    ctx.moveTo(120, 60);
    ctx.lineTo(120, 180);
    // 中
    ctx.moveTo(250, 60);
    ctx.lineTo(250, 120);

    // 右中
    ctx.moveTo(380, 60);
    ctx.lineTo(380, 120);

    // 左下
    ctx.moveTo(180, 180);
    ctx.lineTo(180, 540);

    ctx.stroke();
    ctx.stroke();
    ctx.stroke();
    ctx.stroke();
    ctx.stroke();
    ctx.stroke();
    convertCanvasToImage(canvas)
}

function canvas_text(ctx, text, fontSzie, color, width, height) {
    ctx.font = fontSzie;
    ctx.fillStyle = color || "#000";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, width / 2, height / 2);
}

function convertCanvasToImage(canvas) {
    var image = new Canvas.Image();
    image.src = canvas.toDataURL();
    var base64Data = image.src.replace(/^data:image\/\w+;base64,/, "");
    // var dataBuffer = new Buffer(base64Data, 'base64');
    var dataBuffer = bufferFrom(base64Data, 'base64');
    fs.writeFile(`${__dirname}/images/` + 'financeList.png', dataBuffer, (err) => {})
}

module.exports = {
    drawImage,

}