# 更新日志

## 2020/05/06 添加 stylelint-plus 自动规整排序 css 样式

## 插件市场问题反馈

插件市场服务器似乎出现了一些问题，无法上传更新日志，github 可以查看到最新的代码的提交情况[github 地址点这里](https://github.com/chuzhixin/vue-admin-beautiful)

## [vue-admin-beautiful 演示地址](http://chu1204505056.gitee.io/vue-admin-beautiful)

## ★★★ ☝☝☝ 演示地址,在上方直接点击登录即可！★★★

## 官方问题解答讨论群 972435319

## 鸣谢 HBuilderX,prettier,Vue

## star 如果您觉得帮助到了您，麻烦去 github 给个 star

[github 地址点这里](https://github.com/chuzhixin/vue-admin-beautiful)

## 安装

```bash
# 克隆项目
git clone https://github.com/chuzhixin/vue-element-admin-beautiful.git

# 进入项目目录
cd vue-element-admin-beautiful
# 安装依赖
cnpm i
# 本地开发 启动项目
npm run serve
```

## 浏览器支持情况

Modern browsers and Internet Explorer 11+.

| [<img class="no-margin" src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/edge/edge_48x48.png" alt="IE / Edge" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>IE / Edge | [<img class="no-margin" src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/firefox/firefox_48x48.png" alt="Firefox" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Firefox | [<img class="no-margin" src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/chrome/chrome_48x48.png" alt="Chrome" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Chrome | [<img class="no-margin" src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/safari/safari_48x48.png" alt="Safari" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Safari |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| IE11, Edge                                                                                                                                                                                                                        | last 2 versions                                                                                                                                                                                                                     | last 2 versions                                                                                                                                                                                                                 | last 2 versions                                                                                                                                                                                                                 |
