import Vue from "vue";
import ByuiIcon from "zx-icon";

Vue.component("byui-icon", ByuiIcon);
