import ByuiSwiper from "zx-swiper";

export default ByuiSwiper;
