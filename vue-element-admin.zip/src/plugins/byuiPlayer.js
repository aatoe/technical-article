import { Custom, Flv, Hls, Mp4 } from "zx-player";

const ByuiPlayerMp4 = Mp4;
const ByuiPlayerHls = Hls;
const ByuiPlayerFlv = Flv;
const ByuiPlayerCustom = Custom;
export { ByuiPlayerMp4, ByuiPlayerHls, ByuiPlayerFlv, ByuiPlayerCustom };
