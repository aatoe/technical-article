import { Heading, Img, Keel, Text } from "zx-keel";
import "@/styles/keel-variables.scss";

const ByuiKeel = Keel;
const ByuiKeelHeading = Heading;
const ByuiKeelImg = Img;
const ByuiKeelText = Text;
export { ByuiKeel, ByuiKeelHeading, ByuiKeelImg, ByuiKeelText };
