import ByuiComparison from "zx-comparison";

export default ByuiComparison;
