import ByuiMagnifier from "zx-magnifie";

export default ByuiMagnifier;
