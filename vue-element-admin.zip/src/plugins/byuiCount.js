import ByuiCount from "zx-count";

export default ByuiCount;
