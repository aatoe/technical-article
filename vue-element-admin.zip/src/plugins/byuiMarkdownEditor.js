import ZxMarkdownEditor from "zx-markdown-editor";

const ByuiMarkdownEditor = ZxMarkdownEditor;
export default ByuiMarkdownEditor;
