<template>
  <div class="test-container">
    <el-divider content-position="left">你可以在这里写demo</el-divider>
  </div>
</template>
<script>
export default {
  name: "Test",
  data() {
    return { show: true };
  },
  created() {},
  mounted() {},
  methods: {},
};
</script>
