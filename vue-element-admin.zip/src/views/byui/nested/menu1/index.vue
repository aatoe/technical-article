<template>
  <div class="menu1-container">
    <el-alert :closable="false" title="menu1" type="success">
      <router-view />
    </el-alert>
  </div>
</template>
