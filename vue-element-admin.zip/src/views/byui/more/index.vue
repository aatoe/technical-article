<template>
  <div class="more-container">
    <el-divider content-position="left">
      加群获取更多markdown,全格式不暴露url地址播放器等各种常规组件,当然您也可以选择定制...
    </el-divider>
  </div>
</template>

<script>
export default {
  name: "More",
  components: {},
  data() {
    return {};
  },
  created() {},
  mounted() {},
  methods: {},
};
</script>
