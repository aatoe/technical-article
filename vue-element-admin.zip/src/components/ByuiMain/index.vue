<template>
  <div class="byui-main">
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: "ByuiMain",
};
</script>
<style lang="scss" scoped>
.byui-main {
  margin-right: auto;
  margin-left: auto;
}
</style>
